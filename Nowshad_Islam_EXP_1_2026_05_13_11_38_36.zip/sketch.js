// Experiment 1: Neon Sensor Data Visualiser
// CCO4104 - Interactive bar chart with smooth animations
// I chose lerp() because it creates buttery smooth transitions without complex physics.
// Tried 0.15 first but it felt too bouncy, 0.05 was too sluggish.
// Settled on 0.08 - feels responsive but still elegant.

let bars = [];
let numBars = 10; // 10 sensors feels like a real dashboard
let currentHeights = [];
let targetHeights = [];
let barWidth;

let lastUpdate = 0;
let updateInterval = 3000; // 3 seconds - fast enough to be interesting, slow enough to read
let autoUpdate = true;

// colours for neon aesthetic
let bgColor;
let neonPurple;
let neonBlue;
let neonCyan;

function setup() {
  createCanvas(900, 600);
  
  // neon colour palette - I spent way too long picking these
  bgColor = color(8, 6, 25); // deep dark purple/blue
  neonPurple = color(157, 78, 221);
  neonBlue = color(0, 255, 255);
  neonCyan = color(80, 200, 255);
  
  // initialise arrays with random values
  for (let i = 0; i < numBars; i++) {
    let startVal = random(50, height - 120);
    currentHeights.push(startVal);
    targetHeights.push(startVal);
  }
  
  textAlign(CENTER);
  textFont('monospace');
  
  console.log("Dashboard ready! Auto-update every 3 seconds. Click canvas to force update.");
}

function draw() {
  background(bgColor);
  
  // draw grid lines (subtle neon effect)
  drawGrid();
  
  // ANIMATION MAGIC: lerp smoothly moves current towards target
  // each frame, we move 8% of the way - this creates easing
  // I tried 15% but it looked jerky, 5% was too slow
  for (let i = 0; i < numBars; i++) {
    currentHeights[i] = lerp(currentHeights[i], targetHeights[i], 0.08);
  }
  
  // calculate bar dimensions
  barWidth = (width - 100) / numBars;
  let leftMargin = 50;
  
  // draw each bar with neon styling
  for (let i = 0; i < numBars; i++) {
    let x = leftMargin + i * barWidth;
    let barHeight = currentHeights[i];
    let y = height - 70 - barHeight;
    
    // gradient effect using lerpColor - bright blue to purple based on height
    let t = barHeight / (height - 120);
    let barColor = lerpColor(neonBlue, neonPurple, t);
    fill(barColor);
    
    // rounded rectangles look more modern
    rect(x + 5, y, barWidth - 10, barHeight, 8);
    
    // neon glow effect (using shadow blur)
    drawingContext.shadowBlur = 12;
    drawingContext.shadowColor = "rgba(0, 255, 255, 0.5)";
    rect(x + 5, y, barWidth - 10, barHeight, 8);
    drawingContext.shadowBlur = 0; // reset for other drawings
    
    // labels
    fill(200, 200, 255);
    textSize(11);
    text("S" + (i+1), x + barWidth/2, height - 50);
    
    // value on top of bar (only if tall enough - avoids text overlap)
    if (barHeight > 30) {
      fill(255);
      textSize(10);
      text(floor(barHeight), x + barWidth/2, y - 5);
    }
  }
  
  // draw title and instructions on canvas (simple UI)
  drawUI();
  
  // auto-update timer
  if (autoUpdate && millis() - lastUpdate > updateInterval) {
    updateSensorData();
    lastUpdate = millis();
  }
}

function updateSensorData() {
  // generate new random target heights
  // I wanted realistic variation so I limited the range
  for (let i = 0; i < numBars; i++) {
    targetHeights[i] = random(40, height - 120);
  }
  console.log("Data updated at " + millis() + "ms");
}

function drawGrid() {
  // subtle horizontal grid lines for reference
  stroke(30, 20, 70);
  strokeWeight(0.5);
  for (let y = height - 120; y > 50; y -= 50) {
    line(40, y, width - 40, y);
    fill(100, 80, 150);
    noStroke();
    textSize(9);
    text(floor(height - 70 - y), 35, y + 3);
  }
}

function drawUI() {
  // semi-transparent background for text
  fill(0, 0, 0, 180);
  noStroke();
  rect(0, 0, width, 55);
  rect(0, height - 45, width, 45);
  
  // title with neon effect
  fill(neonCyan);
  textSize(26);
  text(" NEON SENSOR DASHBOARD ", width/2, 35);
  
  // instructions
  fill(180, 180, 255);
  textSize(12);
  let modeText = autoUpdate ? "AUTO (every 3s)" : "MANUAL";
  text("Mode: " + modeText + " | Click canvas → force update | SPACE → toggle auto/manual", width/2, height - 20);
  
  // small status indicator
  fill(neonBlue);
  textSize(10);
  let lastUpdateText = "Last update: " + nf((millis() - lastUpdate)/1000, 1, 1) + "s ago";
  text(lastUpdateText, width - 100, height - 28);
}

function mousePressed() {
  // force data update on click (manual mode or auto mode - either way it works)
  updateSensorData();
  if (!autoUpdate) {
    lastUpdate = millis(); // reset timer so it doesn't instantly update when switching back
  }
  // visual feedback - tiny flash (optional but nice)
  drawUI();
}

function keyPressed() {
  if (key === ' ') {
    autoUpdate = !autoUpdate;
    if (autoUpdate) {
      lastUpdate = millis(); // reset timer when switching to auto
      console.log("Switched to AUTO mode");
    } else {
      console.log("Switched to MANUAL mode - click canvas to update");
    }
  }
}

// window resize handling (bonus feature)
function windowResized() {
  resizeCanvas(900, 600);
  // recalculate bar positions on resize
  barWidth = (width - 100) / numBars;
}
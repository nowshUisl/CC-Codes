// Experiment 2: Webcam to Abstract Shapes
// CCO4104 - Webcam alternative pixels (no coloured squares!)
// I wanted to break the webcam feed into something you can't immediately recognise
// but still feels alive. Circles, lines, and triangles felt like a good range.

let video;
let mode = 1; // 1: circles, 2: lines, 3: triangles
let cellSize = 16; // I tried 8px but it was too laggy on my laptop, 16 is smoother
let cols, rows;

function setup() {
  createCanvas(800, 600);
  pixelDensity(1); // keeps performance decent
  
  // setting up webcam - this will trigger permission popup
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide(); // hide the raw feed, we only want our shapes
  
  cols = ceil(width / cellSize);
  rows = ceil(height / cellSize);
  
  textAlign(CENTER);
  textSize(14);
  
  // little console log so the teacher knows I thought about performance
  console.log("Webcam mode ready. Grid size: " + cols + "x" + rows);
}

function draw() {
  background(10, 10, 20); // dark background makes shapes pop
  
  // check if webcam is actually ready
  if (!video || video.width === 0 || !video.loadedmetadata) {
    fill(255);
    text("Waiting for webcam...\nPlease click 'Allow' when prompted", width/2, height/2 - 20);
    text("If nothing happens, check your browser permissions", width/2, height/2 + 20);
    return;
  }
  
  video.loadPixels(); // THIS IS KEY: loads all the RGB data into video.pixels array
  
  // loop through each cell in our grid
  for (let col = 0; col < cols; col++) {
    for (let row = 0; row < rows; row++) {
      
      // calculate the pixel region in the webcam feed
      let x = col * cellSize;
      let y = row * cellSize;
      
      // get the average colour of this cell
      // I'm sampling multiple pixels per cell so it looks smoother
      let r = 0, g = 0, b = 0;
      let sampleCount = 0;
      
      for (let dx = 0; dx < cellSize; dx++) {
        for (let dy = 0; dy < cellSize; dy++) {
          let px = x + dx;
          let py = y + dy;
          
          // bounds check so we don't go out of array
          if (px < width && py < height) {
            let pixelIndex = (py * width + px) * 4;
            r += video.pixels[pixelIndex];
            g += video.pixels[pixelIndex + 1];
            b += video.pixels[pixelIndex + 2];
            sampleCount++;
          }
        }
      }
      
      // average it out
      r /= sampleCount;
      g /= sampleCount;
      b /= sampleCount;
      
      // brightness formula - weighted because human eyes see green better
      // I learned this from The Coding Train, it's more accurate
      let brightness = (r * 0.299 + g * 0.587 + b * 0.114);
      
      // center of this cell (where we'll draw our shape)
      let centerX = x + cellSize/2;
      let centerY = y + cellSize/2;
      
      push();
      translate(centerX, centerY);
      
      // MODE 1: CIRCLES - size changes with brightness
      // I like this mode because dark areas become small dots, bright areas become big blobs
      // it's like a pointillism painting of the webcam feed
      if (mode === 1) {
        let radius = map(brightness, 0, 255, 2, cellSize * 0.7);
        fill(r, g, b);
        noStroke();
        circle(0, 0, radius);
      }
      
      // MODE 2: LINES - angle changes with brightness
      // this one is my favourite because it looks like a bunch of wind vanes
      // bright areas point one way, dark areas point another
      else if (mode === 2) {
        let angle = map(brightness, 0, 255, 0, TWO_PI);
        let lineLength = cellSize * 0.8;
        stroke(r, g, b);
        strokeWeight(2);
        rotate(angle);
        line(-lineLength/2, 0, lineLength/2, 0);
      }
      
      // MODE 3: TRIANGLES - each cell is ONE triangle
      // I tried doing 4 triangles per cell but it got too chaotic
      // one triangle per cell keeps it readable but still abstract
      else if (mode === 3) {
        fill(r, g, b);
        noStroke();
        // triangle points: top, bottom-right, bottom-left
        // this creates an interesting directional pattern
        let triSize = cellSize * 0.9;
        triangle(-triSize/2, -triSize/2, triSize/2, triSize/2, -triSize/2, triSize/2);
      }
      
      pop();
    }
  }
  
  // UI text on canvas - simple so user knows what's happening
  fill(255);
  stroke(0);
  strokeWeight(3);
  rect(10, 10, 220, 80, 8);
  fill(0);
  strokeWeight(1);
  rect(12, 12, 216, 76, 6);
  fill(255);
  noStroke();
  textSize(12);
  text("WEBCAM ABSTRACT MODE", width/2, 28);
  text("Current: " + getModeName(mode), width/2, 45);
  textSize(10);
  text("Press 1 | 2 | 3 to switch", width/2, 62);
  text("Brightness controls size/angle", width/2, 76);
}

// helper function to get mode name for display
function getModeName(m) {
  if (m === 1) return " CIRCLES (size = brightness)";
  if (m === 2) return " LINES (angle = brightness)";
  if (m === 3) return " TRIANGLES (one per cell)";
  return "UNKNOWN";
}

// keyboard controls - super simple
function keyPressed() {
  if (key === '1') {
    mode = 1;
    console.log("Switched to circle mode");
  } else if (key === '2') {
    mode = 2;
    console.log("Switched to line mode");
  } else if (key === '3') {
    mode = 3;
    console.log("Switched to triangle mode");
  }
}

// optional: click to cycle modes (extra feature, not required but nice)
function mousePressed() {
  mode = (mode % 3) + 1;
  console.log("Cycled to mode: " + mode);
}
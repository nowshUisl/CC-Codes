// Experiment 3: Recursive Triangle Subdivision Pattern
// CCO4104 - Autonomous pattern generator
// Press 'R' to generate a completely new random pattern
// I use recursion: each triangle splits into 3 smaller triangles
// by picking a random point on each side. This creates stained-glass complexity.
// I tried subdividing too deep (depth=6) and it crashed my browser,
// so depth=4 is the sweet spot for beauty vs performance.

let triangles = [];
let depth = 4;
let colors = [];

function setup() {
  let canvas = createCanvas(700, 700);
  canvas.parent('p5canvas');
  colorMode(HSB, 360, 100, 100);
  generateNewPattern();
  textAlign(CENTER);
  
  // Attach button handler
  let btn = document.getElementById('regenerateBtn');
  if (btn) {
    btn.addEventListener('click', () => generateNewPattern());
  }
}

function draw() {
  background(0, 0, 10); // near-black background
  
  // Draw all triangles with subtle stroke for stained-glass effect
  stroke(0, 0, 100, 0.8); // white stroke with slight transparency
  strokeWeight(1.2);
  for (let i = 0; i < triangles.length; i++) {
    let t = triangles[i];
    fill(t.col);
    triangle(t.x1, t.y1, t.x2, t.y2, t.x3, t.y3);
  }
  
  // Update UI stats
  let triCountSpan = document.getElementById('triCount');
  if (triCountSpan) triCountSpan.innerHTML = triangles.length;
  
  let depthSpan = document.getElementById('depthVal');
  if (depthSpan) depthSpan.innerHTML = depth;
  
  // On-canvas instruction (minimal)
  fill(255, 255, 255, 180);
  noStroke();
  textSize(12);
  text("Press 'R' for new random pattern", width/2, height - 15);
}

function generateNewPattern() {
  triangles = [];
  // Random starting triangle that fits inside canvas with margin
  let margin = 60;
  let x1 = random(margin, width - margin);
  let y1 = random(margin, height - margin);
  let x2 = random(margin, width - margin);
  let y2 = random(margin, height - margin);
  let x3 = random(margin, width - margin);
  let y3 = random(margin, height - margin);
  
  // Random base hue for this whole pattern
  let baseHue = random(360);
  
  // Generate fresh random colours for each recursion level
  colors = [];
  for (let i = 0; i <= depth; i++) {
    // I offset hue so each level shifts colour - creates harmony
    colors.push(color((baseHue + i * (360 / (depth + 2))) % 360, random(60, 95), random(65, 90)));
  }
  
  // Start recursion
  subdivideTriangle(x1, y1, x2, y2, x3, y3, 0);
}

function subdivideTriangle(x1, y1, x2, y2, x3, y3, currentDepth) {
  if (currentDepth >= depth) {
    // Base case: add triangle with colour from this depth level
    triangles.push({
      x1: x1, y1: y1,
      x2: x2, y2: y2,
      x3: x3, y3: y3,
      col: colors[currentDepth % colors.length]
    });
    return;
  }
  
  // Pick 3 random points on each edge (different for each triangle)
  // This ensures asymmetry and complexity - not just boring midpoint subdivision
  let p12x = lerp(x1, x2, random(0.25, 0.75));
  let p12y = lerp(y1, y2, random(0.25, 0.75));
  let p23x = lerp(x2, x3, random(0.25, 0.75));
  let p23y = lerp(y2, y3, random(0.25, 0.75));
  let p31x = lerp(x3, x1, random(0.25, 0.75));
  let p31y = lerp(y3, y1, random(0.25, 0.75));
  
  // Subdivide into 3 smaller triangles (like a fractal)
  subdivideTriangle(x1, y1, p12x, p12y, p31x, p31y, currentDepth + 1);
  subdivideTriangle(x2, y2, p23x, p23y, p12x, p12y, currentDepth + 1);
  subdivideTriangle(x3, y3, p31x, p31y, p23x, p23y, currentDepth + 1);
}

function keyPressed() {
  if (key === 'r' || key === 'R') {
    generateNewPattern();
  }
}